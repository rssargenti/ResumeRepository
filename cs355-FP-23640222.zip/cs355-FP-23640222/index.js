const fs = require('fs');
const http = require('http');
const https = require('https');
const qs = require('querystring');
const port = 3000;
const server = http.createServer();
const consumer_key = '97260-efdc1e2b213dc7a31bd72e3f';
///////////////////////////////////////////
/**TODO:
 * enforce user rate limit
 * 
 */


server.on("request", connection_handler);

function connection_handler(req, res){

	console.log(`Request: ${req.url}\nFrom: ${req.socket.remoteAddress}`);

    //root of website
	if(req.url === '/' || req.url === '/?'){
		const main = fs.createReadStream('html/homepage.html');
		res.writeHead(200, {'Content-Type':'text/html'});
        console.log("200 OK to user");
		main.pipe(res);
	}
    //search page, results from HTML are brought here, begins API calls.
	else if(req.url.startsWith("/search")){
		url_object = new URL('http://localhost:3000'+req.url);
		string = url_object.searchParams.get('animal'); 
        //Redlist request results are saved in cache.json, allows for more efficient use of API calls
        if(fs.existsSync("./cache.json")){
            let cache = fs.readFileSync('./cache.json');
            let parse_cache = JSON.parse(cache);
            let exp_date = parse_cache.expiration;
            let now_date = Date.now()/1000;
            if(exp_date < now_date){
                console.log("cache expired, making new request to redlist...");
                RedListRequest(string, res);
            }
            else if(parse_cache.hasOwnProperty(string)){
                let time = parse_cache.expiration-Date.now()/1000;
                console.log("time left before cache expires (seconds): ", time);
                console.log("using cached name:", parse_cache[string]);
                PocketAuth_request_token(parse_cache[string], res);
            }
            else{
                console.log(`name "${string}" not found in cache, making new request to redlist...`);
                RedListRequest(string, res);
            }
        }
        else{
            console.log("making new request to redlist and creating cache...");
            RedListRequest(string, res);
        }
        console.log("call in progress...");
	}
    //User redirected here momentarily, helps to pass information into the get_auth_token method
    else if(req.url.startsWith("/authorized")){
        let auth_url = new URL('http://localhost:3000'+req.url) 
        let rlurl = auth_url.searchParams.get('rlurl');
        let code = auth_url.searchParams.get('code');
        PocketAuth_get_auth_token(consumer_key, code, rlurl, res);
    }
    //when request finished successfully, user brought to this page.
    else if(req.url.startsWith("/finished")){
        const main = fs.createReadStream('html/input_accepted.html');
		res.writeHead(200, {'Content-Type':'text/html'});
        console.log("200 OK to user");
		main.pipe(res);
    }
    //errors in the redlist request or the pocket add request will bring the user here with a status code.
    else if(req.url.startsWith('/error')){
        let err_url = new URL('http://localhost:3000'+req.url);
        let statuscode = err_url.searchParams.get('statuscode');
        res.write(`Something went wrong. status code:${statuscode}`);
        res.end();
    }
	else{
		res.write("404 Not Found");
		res.end();
	}
}

server.on("listening", listening_handler);
function listening_handler(){
	console.log(`Now Listening on Port ${port}`);
}

server.listen(port);

//begins call to IUCN Red List API. information from this API required for further requests (may be cached already).
function RedListRequest(name, s_res){
let namefixed = name.replace(" ", "%20").toLowerCase();
let search_endpoint = `https://apiv3.iucnredlist.org/api/v3/weblink/${namefixed}`;
console.log(`searching for ${search_endpoint}`);
let search_req = https.request(search_endpoint, (res) =>{
    console.log('iucnredlist response:', res.statusCode);
    if(res.statusCode != 200){
        s_res.write(`${res.statusCode}, ${res.statusMessage}`);
    }
    let data;
    let parsed;
    res.on('data', (d) => {
        data = d;
    });
    res.on('end', () => {
        parsed = JSON.parse(data);
        rlurl = parsed.rlurl;
        if(rlurl === undefined){
            s_res.writeHead(302, {Location: "http://localhost:3000/error?statuscode= 404"}).end();
            return;
        }
        species = parsed.species
        console.log('call finished.')
        console.log('rlurl:', rlurl);
        console.log('species:', species);
        let cache_exists = false;
        let cache_valid = false;
        if(fs.existsSync("./cache.json")){
            cache_exists = true;
            let temp_data = fs.readFileSync("./cache.json");
            let temp_cache = JSON.parse(temp_data);
            let exp_date = temp_cache.expiration;
            let now_date = Date.now()/1000;
            if(exp_date > now_date)
                cache_valid = true;
        }
        if(!cache_exists || !cache_valid){
            let exp = Date.now()/1000;
            exp = exp+3600;
            let cache = JSON.stringify({[species]:rlurl, expiration:exp});
            fs.writeFileSync("./cache.json", cache);
            console.log("new cache created. First value:", species); 
        }
        else if(cache_exists){
            let temp_data = fs.readFileSync("./cache.json");
            let temp_cache = JSON.parse(temp_data);
            let time = temp_cache.expiration-Date.now()/1000;
            console.log("time left before cache expires (seconds): ", time);
            temp_cache[species] = rlurl;
            fs.writeFileSync("./cache.json", JSON.stringify(temp_cache));
            console.log("new name written to cache:", species);
        }
        PocketAuth_request_token(rlurl, s_res);
    })
});
search_req.end();
}

//Gets code from Pocket API, acts similar to a client secret but is generated new for each user request.
function PocketAuth_request_token(rlurl, s_res){
    console.log("requesting code from Pocket API...");
    let redirect_uri = 'http%3A%2F%2Flocalhost%3A3000%2F';
    let code_endpoint = `https://getpocket.com/v3/oauth/request?consumer_key=${consumer_key}&redirect_uri=${redirect_uri}`;
    const header = {'Content-Type':'application/x-www-form-urlencoded'};
    let options = {'method':'POST', 'headers':header};
    let code_req = https.request(code_endpoint, options);
    code_req.on('response', return_message);
    function return_message(incoming_message){
        let data = [];
        console.log("/oauth/request", incoming_message.statusCode);
        if(incoming_message.statusCode != 200){
            s_res.write(`${incoming_message.statusCode}, ${incoming_message.statusMessage}`);
        }
        incoming_message.on('data', (d) => {
            data.push(d);
        });
        incoming_message.on('end', () => {
            let fixed_data = data.join().replace(",", "");
            
            let decodedUrl = decodeURIComponent(fixed_data);
           
            let code = decodedUrl.replace("code=", "");
            PocketAuth_user_login(rlurl, code, s_res);
        });
    }
    code_req.end();
}

//Begins user login process on Pocket's website. Redirects user to Pocket's sign in page, then back to one of our pages.
function PocketAuth_user_login(rlurl, code, s_res){
    const auth_endpoint = "https://getpocket.com/auth/authorize";
    let params = qs.stringify({rlurl:rlurl, code:code});
    console.log('redirect uri:', `http://localhost:3000/authorized?${params}`);
    const redirect_uri = `http://localhost:3000/authorized?${params}`;
    const request_token = code;
    let uri = qs.stringify({request_token, redirect_uri});
    let full_url = `${auth_endpoint}?${uri}`;
    console.log('return login:', full_url);
    
    s_res.writeHead(302, {Location: full_url}).end();
    console.log("/auth/authorize 302 redirect to localhost:3000/authorized");
    
}

//gets user specific access token from Pocket, must also be generated for each request.
function PocketAuth_get_auth_token(consumer_key, code, rlurl, s_res){
    const auth_token_endpoint = "https://getpocket.com/v3/oauth/authorize"
    
    let uri = qs.stringify({consumer_key, code});
    let auth_token_req = https.request(`${auth_token_endpoint}?${uri}`, (res) => {
        let data = [];
        console.log("/oauth/authorize:", res.statusCode);
        if(res.statusCode != 200){
            s_res.write(`${res.statusCode}, ${res.statusMessage}`);
        }
        res.on("data", (d) => {
            data.push(d);
        });
        res.on("end", () => {
            console.log(data.join());
            let decodedUrl = decodeURIComponent(data.join());
            console.log(decodedUrl);
            let access_token = new URL(`https://getpocket.com/v3/add?${decodedUrl}`);
            access_token = access_token.searchParams.get('access_token');
            console.log(access_token);
            pocket_authenticated_request(access_token, rlurl, s_res);
        })
    });
    auth_token_req.end();
}

//Makes an add request to pocket, if successful the user's article will appear in their Pocket library.
function pocket_authenticated_request(access_token, rlurl, s_res){
    const add_endpoint = "https://getpocket.com/v3/add";
    const add_req = https.request(`${add_endpoint}?url=${rlurl}&consumer_key=${consumer_key}&access_token=${access_token}`, (res) => {
        console.log("add request response:", res.statusCode);
        
        if(res.statusCode == 200){
            console.log('webpage added successfully!');
            s_res.writeHead(302, {Location: "http://localhost:3000/finished"}).end();
        }
        else{
            console.log('something went wrong...');
            s_res.writeHead(302, {Location: `http://localhost:3000/error?statuscode=${res.statusCode}`}).end();
        }
    });
    add_req.end();
}
